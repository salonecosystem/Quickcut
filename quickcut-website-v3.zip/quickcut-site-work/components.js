/* ═══════════════════════════════════════════════════════════════
   QUICK CUT ECOSYSTEM — Shared Components v2.0
   Payment Gateway Ready | Business Verification Compliant
   Contact: salonecosystem@gmail.com | Koramangala, Bangalore
═══════════════════════════════════════════════════════════════ */

const QC = {
  activePage: '',

  /* ── Business Info (single source of truth) ── */
  biz: {
    name:    'Quick Cut Ecosystem',
    email:   'salonecosystem@gmail.com',
    phone:   '+91 80-4568-9201',
    address: 'No. 1-E, ECO, 2nd Floor, Koramangala',
    city:    'Bangalore, Karnataka — 560034',
    hours:   'Mon–Sat: 9:00 AM – 7:00 PM IST',
    gst:     '29AABCQ1234A1Z5',
    category:'Beauty & Wellness · Salon Booking Platform',
    apps: {
      customer: 'https://median.co/share/eekwzqe#apk',
      salon:    'https://median.co/share/odpjjwk#apk',
      agent:    'https://median.co/share/qdlppqp#apk'
    }
  },

  nav: `
<nav class="nav" id="mainNav" role="navigation" aria-label="Main navigation">
  <div class="nav-inner">
    <a href="index.html" class="nav-logo" aria-label="Quick Cut Ecosystem Home">
      <div class="nav-logo-mark" aria-hidden="true">✂</div>
      Quick<span>Cut</span>
    </a>
    <ul class="nav-links" id="navLinks" role="menubar">
      <li role="none"><a href="index.html"     data-page="home"     role="menuitem">Home</a></li>
      <li role="none"><a href="about.html"     data-page="about"    role="menuitem">About</a></li>
      <li role="none"><a href="services.html"  data-page="services" role="menuitem">Services</a></li>
      <li role="none"><a href="customer.html"  data-page="customer" role="menuitem">Customer App</a></li>
      <li role="none"><a href="salon.html"     data-page="salon"    role="menuitem">Salon App</a></li>
      <li role="none"><a href="agent.html"     data-page="agent"    role="menuitem">Agent App</a></li>
      <li role="none"><a href="contact.html"   data-page="contact"  role="menuitem">Contact</a></li>
      <li role="none"><a href="index.html#download" class="nav-cta" role="menuitem">Get Apps ↓</a></li>
    </ul>
    <button class="hamburger" id="hamburger" aria-label="Toggle menu" aria-expanded="false">☰</button>
  </div>
</nav>

<div class="mobile-menu" id="mobileMenu" role="dialog" aria-label="Mobile navigation">
  <a href="index.html">🏠 Home</a>
  <a href="about.html">🏢 About Us</a>
  <a href="services.html">⚡ Services</a>
  <a href="customer.html">👤 Customer App</a>
  <a href="salon.html">💈 Salon Owner App</a>
  <a href="agent.html">🤝 Agent App</a>
  <a href="contact.html">📞 Contact Us</a>
  <div style="border-top:1px solid var(--border);margin:10px 0;padding-top:10px;">
    <a href="privacy.html">🔒 Privacy Policy</a>
    <a href="terms.html">📄 Terms &amp; Conditions</a>
    <a href="refund.html">💰 Refund Policy</a>
    <a href="shipping.html">📦 Delivery Policy</a>
  </div>
  <a href="index.html#download" class="btn btn-gold" style="text-align:center;justify-content:center;margin-top:8px;">Get Free Apps</a>
</div>`,

  footer: `
<div class="gold-line"></div>

<!-- ── TRUST BAR above footer ── -->
<div style="background:#f0f7f3;border-top:1px solid #d5e8db;border-bottom:1px solid #d5e8db;padding:18px 0;">
  <div class="container">
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
      <div style="display:flex;align-items:center;gap:8px;font-size:.8rem;font-weight:600;color:#1b5e37;">
        <span style="font-size:1.1rem;">🔒</span> SSL Secured Website
      </div>
      <div style="display:flex;align-items:center;gap:8px;font-size:.8rem;font-weight:600;color:#1b5e37;">
        <span style="font-size:1.1rem;">✅</span> Payment Gateway Verified
      </div>
      <div style="display:flex;align-items:center;gap:8px;font-size:.8rem;font-weight:600;color:#1b5e37;">
        <span style="font-size:1.1rem;">💳</span> UPI · Cards · Wallets Accepted
      </div>
      <div style="display:flex;align-items:center;gap:8px;font-size:.8rem;font-weight:600;color:#1b5e37;">
        <span style="font-size:1.1rem;">🏆</span> Trusted Salon Marketplace
      </div>
      <div style="display:flex;align-items:center;gap:8px;font-size:.8rem;font-weight:600;color:#1b5e37;">
        <span style="font-size:1.1rem;">📍</span> Bangalore, India
      </div>
    </div>
  </div>
</div>

<footer role="contentinfo">
  <div class="container">
    <div class="footer-grid">

      <!-- Brand -->
      <div class="footer-brand">
        <div class="logo">✂ Quick<em>Cut</em></div>
        <p style="margin-bottom:10px;">India's trusted salon booking ecosystem — connecting customers, salon owners, and field agents on one smart platform.</p>
        <div style="font-size:.78rem;color:rgba(255,255,255,.28);line-height:1.7;margin-bottom:14px;">
          <div>📍 No. 1-E, ECO, 2nd Floor, Koramangala</div>
          <div>&nbsp;&nbsp;&nbsp;&nbsp;Bangalore, Karnataka — 560034</div>
          <div style="margin-top:6px;">✉️ <a href="mailto:salonecosystem@gmail.com" style="color:rgba(200,150,42,.7);">salonecosystem@gmail.com</a></div>
          <div>📞 <a href="tel:+918045689201" style="color:rgba(200,150,42,.7);">+91 80-4568-9201</a></div>
          <div style="margin-top:6px;">⏰ Mon–Sat: 9:00 AM – 7:00 PM IST</div>
        </div>
        <div style="font-size:.7rem;color:rgba(255,255,255,.18);margin-bottom:14px;">
          Business Category: Beauty &amp; Wellness · Salon Booking Platform
        </div>
        <div class="social" aria-label="Social media links">
          <a href="#" title="Instagram" aria-label="Instagram">In</a>
          <a href="#" title="Facebook" aria-label="Facebook">Fb</a>
          <a href="#" title="Twitter/X" aria-label="Twitter">𝕏</a>
          <a href="#" title="YouTube" aria-label="YouTube">▶</a>
          <a href="#" title="LinkedIn" aria-label="LinkedIn">Li</a>
        </div>
      </div>

      <!-- Platform -->
      <div class="footer-col">
        <h5>Platform</h5>
        <ul>
          <li><a href="customer.html">Customer App</a></li>
          <li><a href="salon.html">Salon Owner App</a></li>
          <li><a href="agent.html">Agent App</a></li>
          <li><a href="services.html">All Services</a></li>
          <li><a href="index.html#download">Get Apps Free</a></li>
          <li><a href="index.html#faq">FAQs</a></li>
        </ul>
      </div>

      <!-- Company -->
      <div class="footer-col">
        <h5>Company</h5>
        <ul>
          <li><a href="about.html">About Us</a></li>
          <li><a href="contact.html">Contact Us</a></li>
          <li><a href="contact.html#careers">Careers</a></li>
          <li><a href="contact.html#partner">Partner With Us</a></li>
          <li><a href="about.html#mission">Mission &amp; Vision</a></li>
          <li><a href="index.html#testimonials">Testimonials</a></li>
        </ul>
      </div>

      <!-- Legal — ALL links required for payment gateway -->
      <div class="footer-col">
        <h5>Legal &amp; Policies</h5>
        <ul>
          <li><a href="privacy.html">🔒 Privacy Policy</a></li>
          <li><a href="terms.html">📄 Terms &amp; Conditions</a></li>
          <li><a href="refund.html">💰 Refund &amp; Cancellation</a></li>
          <li><a href="shipping.html">📦 Delivery Policy</a></li>
          <li><a href="cookies.html">🍪 Cookie Policy</a></li>
          <li><a href="contact.html">📞 Customer Support</a></li>
        </ul>
      </div>

    </div>

    <!-- Payment Methods Strip -->
    <div style="border-top:1px solid rgba(255,255,255,.06);border-bottom:1px solid rgba(255,255,255,.06);padding:20px 0;margin:0 0 20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;">
      <div style="font-size:.78rem;color:rgba(255,255,255,.3);font-weight:600;">
        🔒 Secure Payment Methods Accepted:
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">UPI</span>
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">Visa</span>
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">Mastercard</span>
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">Net Banking</span>
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">Wallets</span>
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">PayTM</span>
        <span style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:6px 12px;font-size:.72rem;font-weight:700;color:rgba(255,255,255,.5);">GPay</span>
      </div>
      <div style="display:flex;align-items:center;gap:6px;font-size:.72rem;color:rgba(255,255,255,.28);">
        <span>🔐</span> 256-bit SSL Encrypted
      </div>
    </div>

    <!-- Bottom bar -->
    <div class="footer-bottom">
      <p>© 2025 Quick Cut Ecosystem. All rights reserved. Registered in Bangalore, Karnataka, India.</p>
      <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;">
        <a href="privacy.html">Privacy</a>
        <a href="terms.html">Terms</a>
        <a href="refund.html">Refund</a>
        <a href="shipping.html">Delivery</a>
        <a href="contact.html" style="color:rgba(200,150,42,.7);">📧 salonecosystem@gmail.com</a>
      </div>
    </div>
  </div>
</footer>`,

  stickyBar: `
<div class="sticky-dl" id="stickyDl" role="complementary" aria-label="Download apps">
  <div class="sticky-dl-text"><strong>QuickCut</strong> — 3 Free Apps</div>
  <div class="sticky-dl-btns">
    <a href="https://median.co/share/eekwzqe#apk" target="_blank" rel="noopener" class="sticky-dl-btn c" aria-label="Open Customer App">👤 Customer</a>
    <a href="https://median.co/share/odpjjwk#apk"    target="_blank" rel="noopener" class="sticky-dl-btn s" aria-label="Open Salon App">💈 Salon</a>
    <a href="https://median.co/share/qdlppqp#apk"   target="_blank" rel="noopener" class="sticky-dl-btn a" aria-label="Open Agent App">🤝 Agent</a>
  </div>
</div>`,

  scrollTop: `<button class="scroll-top" id="scrollTop" aria-label="Back to top">↑</button>`,

  /* ── HEAD meta injector ── call in <head> before </head> ── */
  headMeta(title, desc, page) {
    return `
  <meta name="robots" content="index, follow"/>
  <meta name="author" content="Quick Cut Ecosystem"/>
  <meta name="copyright" content="© 2025 Quick Cut Ecosystem"/>
  <meta name="geo.region" content="IN-KA"/>
  <meta name="geo.placename" content="Bangalore"/>
  <meta name="business:contact_data:locality" content="Koramangala, Bangalore"/>
  <meta name="business:contact_data:country_name" content="India"/>
  <meta name="theme-color" content="#1b5e37"/>
  <meta property="og:site_name" content="Quick Cut Ecosystem"/>
  <meta property="og:title" content="${title}"/>
  <meta property="og:description" content="${desc}"/>
  <meta property="og:type" content="website"/>
  <meta property="og:locale" content="en_IN"/>
  <meta name="twitter:card" content="summary_large_image"/>
  <meta name="twitter:title" content="${title}"/>
  <meta name="twitter:description" content="${desc}"/>
  <link rel="icon" type="image/svg+xml" href="favicon.svg"/>
  <link rel="canonical" href="https://quickcutecosystem.in/${page}"/>
  <script type="application/ld+json">
  {"@context":"https://schema.org","@type":"LocalBusiness",
   "name":"Quick Cut Ecosystem","@id":"https://quickcutecosystem.in",
   "url":"https://quickcutecosystem.in","email":"salonecosystem@gmail.com",
   "telephone":"+91-80-4568-9201",
   "description":"India's trusted salon booking and management platform",
   "priceRange":"Free",
   "currenciesAccepted":"INR",
   "paymentAccepted":"Cash, UPI, Credit Card, Debit Card, Net Banking",
   "areaServed":"India",
   "category":"Beauty and Personal Care",
   "address":{"@type":"PostalAddress","streetAddress":"No. 1-E, ECO, 2nd Floor, Koramangala",
    "addressLocality":"Bangalore","addressRegion":"Karnataka","postalCode":"560034","addressCountry":"IN"},
   "openingHoursSpecification":[{"@type":"OpeningHoursSpecification","dayOfWeek":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"opens":"09:00","closes":"19:00"}]
  }
  <\/script>`;
  },

  init(page) {
    this.activePage = page;
    document.body.insertAdjacentHTML('afterbegin', this.nav);
    document.body.insertAdjacentHTML('beforeend', this.footer);
    document.body.insertAdjacentHTML('beforeend', this.stickyBar);
    document.body.insertAdjacentHTML('beforeend', this.scrollTop);

    // Active nav
    document.querySelectorAll('[data-page]').forEach(a => {
      if (a.dataset.page === page) a.classList.add('active');
    });

    // Hamburger
    const ham = document.getElementById('hamburger');
    const mob = document.getElementById('mobileMenu');
    ham.addEventListener('click', () => {
      const open = mob.classList.toggle('open');
      ham.setAttribute('aria-expanded', open);
      ham.textContent = open ? '✕' : '☰';
    });
    // Close on outside click
    document.addEventListener('click', e => {
      if (!ham.contains(e.target) && !mob.contains(e.target)) {
        mob.classList.remove('open');
        ham.setAttribute('aria-expanded', 'false');
        ham.textContent = '☰';
      }
    });

    // Scroll top
    const st = document.getElementById('scrollTop');
    window.addEventListener('scroll', () => {
      st.classList.toggle('visible', window.scrollY > 400);
    }, { passive: true });
    st.addEventListener('click', () => window.scrollTo({ top:0, behavior:'smooth' }));

    // Scroll reveal
    const ro = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('visible'); ro.unobserve(e.target); }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.reveal').forEach(el => ro.observe(el));

    // FAQ accordion
    document.querySelectorAll('.faq-q').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.closest('.faq-item');
        const isOpen = item.classList.contains('open');
        document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
        if (!isOpen) item.classList.add('open');
      });
    });

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const group = btn.dataset.group || 'default';
        const target = btn.dataset.tab;
        document.querySelectorAll(`.tab-btn[data-group="${group}"]`).forEach(b => b.classList.remove('active'));
        document.querySelectorAll(`.tab-content[data-group="${group}"]`).forEach(c => { c.style.display = 'none'; });
        btn.classList.add('active');
        const el = document.querySelector(`.tab-content[data-tab="${target}"]`);
        if (el) el.style.display = 'grid';
      });
    });

    // Sticky bar
    const hero = document.querySelector('.hero-dark, .page-hero');
    const bar  = document.getElementById('stickyDl');
    if (hero && bar) {
      new IntersectionObserver(([e]) => {
        bar.style.display = e.isIntersecting ? 'none' : 'flex';
      }, { threshold: 0.1 }).observe(hero);
    }
  }
};
